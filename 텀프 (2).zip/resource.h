﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++에서 생성한 포함 파일입니다.
// test02.rc에서 사용되고 있습니다.
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_TEST02_DIALOG               102
#define IDR_MAINFRAME                   128
#define IDC_EDIT_BOOKNAME               1000
#define IDC_BUTTON_OPEN                 1001
#define IDC_SPIN_SHEET                  1002
#define IDC_EDIT20                      1003
#define IDC_EDITNUM                     1003
#define IDC_SPIN_TYPE                   1004
#define IDC_EDIT1                       1005
#define IDC_ALLBOOK1                    1005
#define IDC_EDIT21                      1006
#define IDC_INFO1                       1006
#define IDC_                            1006
#define IDC_EDIT_MOV                    1006
#define IDC_EDIT_TYPe                   1006
#define IDC_EDIT3                       1007
#define IDC_ALLBOOK3                    1007
#define IDC_EDIT5                       1008
#define IDC_EDIT2                       1008
#define IDC_ALLBOOK2                    1008
#define IDC_EDIT7                       1009
#define IDC_INWINDOW1                   1009
#define IDC_CHAPTER1                    1009
#define IDC_EDIT8                       1010
#define IDC_INWINDOW3                   1010
#define IDC_CHAPTER3                    1010
#define IDC_EDIT9                       1011
#define IDC_INWINDOW2                   1011
#define IDC_CHAPTER2                    1011
#define IDC_LIST_CHARS                  1012
#define IDC_STATIC_SHEETS               1013
#define IDC_EDIT10                      1014
#define IDC_CHARINFO1                   1014
#define IDC_EDIT11                      1015
#define IDC_CHARINFO2                   1015
#define IDC_WORD1                       1017
#define IDC_WORD2                       1018
#define IDC_LIST1                       1019
#define IDC_STATIC_MOV                  1021
#define IDC_STATIC_TYPES                1021
#define IDC_STATIC_FRAME                1022

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        153
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1023
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
