﻿
// test02Dlg.h: 헤더 파일
//



#pragma once
struct SCharInfo :public CDialogEx {
	CString m_char;
	int m_type, m_sheet, m_sx, m_sy, m_line, m_order, m_width, m_height;


	SCharInfo()
	{
		m_char.Empty();
	}

};


class CTypeDB :public CDialogEx {
public:
	int m_nSheet;
	int m_nChar;
	CArray<SCharInfo*, SCharInfo*> m_Chars;
	
	BOOL ReadCSVFile(CString filename);

	CTypeDB::CTypeDB()
	{
		m_nSheet = 0;
		m_nChar = 0;
	}

};

struct WordInfo :public CDialogEx {
	int wordsheet, wordsx, wordsy;
	CString worddir;
};
// Ctest02Dlg 대화 상자
class Ctest02Dlg : public CDialogEx
{
// 생성입니다.
public:
	Ctest02Dlg(CWnd* pParent = nullptr);	// 표준 생성자입니다.
	//VTK	
	vtkSmartPointer<vtkRenderWindow> m_vtkWindow;
	void InitVtkWindow(void* hWnd);
	void ResizeVtkWindow();

	void RemoveAll();
	CString str;
	
	CTypeDB db;
	CArray <CRect, CRect&> m_rect; // 사각형 위치랑 크기값들 저장되는 공간(장 수별로)
	SCharInfo* pSCharInfoWord = new SCharInfo;
	CArray <WordInfo*, WordInfo*> m_word; // 활자정보들을 저장한 배열

	int movtype; // 활자 종류 수
	int lettype; // 글자 종류 수
	int val; // 스핀 컨트롤 1-1
	BOOL sval; // 스핀 컨트롤 1-2
	int spval; // 스핀 컨트롤 2-2

	int chapnum; // 장 번호
	int chaplet1; // 장 내 글자 수
	int chaplet2; // 장 내 글자 종류
	int chaplet3; // 장 내 활자 수

	int allmovnum; // 같은 장내 전체 활자수
	int movnum; // 같은 장내 활자수번호
	int arrsize; // 배열크기 저장

	CString wordinf1; // 글자 정보(유니코드)
	int wordinf2; // 글자 정보(시트)
	int wordinf3; // 글자 정보(line)
	int wordinf4; // 글자 정보(order)

	void DeleteArr();
	void ReadAllBook();
	void ReadChapter(int chapnum);
	void ReadMovable();
	void SelectBox(int chapnum);
// 모래시계는 OnEnChangeEditnum(), OnClickedButtonOpen(), 

// 대화 상자 데이터입니다.
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_TEST02_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV 지원입니다.


// 구현입니다.
protected:
	HICON m_hIcon;

	// 생성된 메시지 맵 함수
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnClickedButtonOpen();
	CEdit m_edsheet;
	CSpinButtonCtrl m_spsheet;
	afx_msg void OnDeltaposSpinSheet(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnEnChangeEditnum();

//	CBitmapButton m_button;
//	CGdipButton m_button;
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
//	CListBox m_listchars;
	CListCtrl m_list;
	afx_msg void OnNMClickListChars(NMHDR* pNMHDR, LRESULT* pResult);
//	CEdit m_edinfo;
	afx_msg void OnDeltaposSpinType(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnEnChangeInfo1();
//	CEdit m_edmov;
	CSpinButtonCtrl m_spmov;
	CEdit m_edmov;
};







