﻿
// test02Dlg.cpp: 구현 파일
//

#include "pch.h"
#include "framework.h"
#include "test02.h"
#include "test02Dlg.h"
#include "afxdialogex.h"
#include "afxwin.h"
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>
#include <atlstr.h>
#include <atlimage.h> 
#include <vtkSTLReader.h>


#pragma comment(linker, "/entry:WinMainCRTStartup /subsystem:console")

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

#define HALFTONE 4

using namespace std;
// 응용 프로그램 정보에 사용되는 CAboutDlg 대화 상자입니다.
void Ctest02Dlg::DeleteArr()
{
	// m_Chars의 추가배열 삭제
	BOOL del = TRUE;
	while (del)
		if (db.m_Chars.GetSize() > arrsize)
		{
			db.m_Chars.RemoveAt(db.m_Chars.GetSize() - 1);
		}
		else if (db.m_Chars.GetSize() == arrsize)
			del = FALSE;
}
void Ctest02Dlg::RemoveAll()
{
	// m_Chars 배열 삭제
	for (int i = 0; i < db.m_Chars.GetSize(); i++)
	{
		SCharInfo* pSCharInfo = db.m_Chars.GetAt(i);

		if (pSCharInfo == NULL)
			continue;
		delete pSCharInfo;

		pSCharInfo = NULL;
	}
	db.m_Chars.RemoveAll();
}

BOOL CTypeDB::ReadCSVFile(CString filename)
{
	// CSV파일 읽기
	CString strFilePath = _T("");
	strFilePath = filename;

	FILE* fp = NULL;
	fopen_s(&fp, (char*)(LPCTSTR)filename, "r"); // filename의 파일을 Read한다.

	// 파일을 읽었을 때
	if (fp)
	{
		char szBook[2048] = { 0, };
		memset(szBook, NULL, 2048);

		// 구조체를 생성하고 m_Chars 배열에 저장
		while (fgets(szBook, 2048, fp))
		{
			SCharInfo* pSCharInfo = new SCharInfo;
			CString strBook;
			strBook.Format(_T("%s"), szBook);
			memset(szBook, NULL, 2048);

			if (strBook.Find(_T("#")) >= 0)

				continue;

			strBook.Remove('\r');
			strBook.Remove('\n');

			CString rString;
			int nSubString = 0;

			while (AfxExtractSubString(rString, strBook, nSubString++, ','))
			{
				switch (nSubString)
				{
				case 1: pSCharInfo->m_char = rString;
					break;
				case 2: pSCharInfo->m_type = _ttoi(rString);
					break;
				case 3: pSCharInfo->m_sheet = _ttoi(rString);
					m_nSheet = pSCharInfo->m_sheet;  break;
				case 4: pSCharInfo->m_sx = _ttoi(rString);
					break;
				case 5: pSCharInfo->m_sy = _ttoi(rString);
					break;
				case 6: pSCharInfo->m_line = _ttoi(rString);
					break;
				case 7: pSCharInfo->m_order = _ttoi(rString);
					break;
				case 8: pSCharInfo->m_width = _ttoi(rString);
					break;
				case 9: pSCharInfo->m_height = _ttoi(rString);
					m_nChar++;  break;
				}
			}
			m_Chars.Add(pSCharInfo);
		}
		m_nChar--;

		fclose(fp); // 파일 닫기
		return 1;
	}
	else
	{
		return 0;
	} // 파일 읽기에 실패한 경우
}
void Ctest02Dlg::ReadAllBook()
{
	lettype = db.m_nChar;
	movtype = db.m_nChar;

	// m_Chars 배열을 2행부터 읽어 글자 종류 수와 활자 수 계산
	for (int i = 1; i < db.m_Chars.GetSize(); i++)
	{
		BOOL overlap = FALSE; // for문에서 글자가 중복계산 되는 것을 방지
		SCharInfo* pSCharInfo1 = db.m_Chars.GetAt(i);

		// 중복 확인
		for (int j = 0; j < i - 1; j++)
		{
			SCharInfo* pSCharInfo2 = db.m_Chars.GetAt(j);
			if (pSCharInfo1->m_char == pSCharInfo2->m_char)
			{
				overlap = TRUE;
				break;
			}
			else
				overlap = FALSE;
		}

		// 중복이 아닐 시
		if (overlap == FALSE)
		{
			for (int j = i + 1; j < db.m_Chars.GetSize(); j++)
			{
				SCharInfo* pSCharInfo2 = db.m_Chars.GetAt(j);
				if (pSCharInfo1->m_char == pSCharInfo2->m_char)
				{
					lettype--; //글자 종류 수
					if (pSCharInfo1->m_type == pSCharInfo2->m_type)
					{
						movtype--; //활자 수
					}
				}
			}
		}
	}
}
void Ctest02Dlg::ReadChapter(int chapnum)
{

	// sheet번호가 동일한 구조체(글자) 수 세기
	for (int i = 1; i < db.m_Chars.GetSize(); i++)
	{
		SCharInfo* pSCharInfo = db.m_Chars.GetAt(i);
		if (pSCharInfo->m_sheet == chapnum)
		{
			chaplet1++;
		}
	}

	chaplet2 = chaplet1;
	chaplet3 = chaplet1;

	// 같은 장 내에서 글자 종류 수와 활자 종류 수 세기
	for (int i = 1; i < db.m_Chars.GetSize(); i++)
	{
		BOOL overlap = FALSE;
		SCharInfo* pSCharInfo1 = db.m_Chars.GetAt(i);

		// 중복 확인
		if (pSCharInfo1->m_sheet == chapnum)
		{
			for (int j = 0; j < i - 1; j++)
			{
				SCharInfo* pSCharInfo2 = db.m_Chars.GetAt(j);
				if (pSCharInfo1->m_char == pSCharInfo2->m_char && pSCharInfo2->m_sheet == chapnum)
				{
					overlap = TRUE;
					break;
				}
				else
					overlap = FALSE;
			}
		}

		// 중복이 아닐 시
		if (overlap == FALSE && pSCharInfo1->m_sheet == chapnum)
		{
			for (int j = i + 1; j < db.m_Chars.GetSize(); j++)
			{

				SCharInfo* pSCharInfo2 = db.m_Chars.GetAt(j);
				if (pSCharInfo1->m_char == pSCharInfo2->m_char && pSCharInfo2->m_sheet == chapnum)
				{
					chaplet2--;
					if (pSCharInfo1->m_type == pSCharInfo2->m_type)
					{
						chaplet3--;
					}
				}
			}
		}
	}
}

void Ctest02Dlg::ReadMovable()
{
	m_word.RemoveAll(); // 활자배열 초기화

	//리스트 삭제
	m_list.DeleteAllItems();
	m_list.DeleteColumn(0);
	m_list.DeleteColumn(0);
	m_list.DeleteColumn(0);

	// 글자 이미지 불러오기
	HRESULT hResult;
	CImage Image;
	CString str1;
	CString dirstr;
	CFileFind finder;
	CClientDC dc(this);

	int arrcnt = 0; // m_word 배열카운트
	int subcnt = 0; //카운트보조

	//CFindFile을 이용하여 글자 이미지 찾기
	BOOL findfile = finder.FindFile("C:\\Users\\82107\\Desktop\\응프텀프\\텀프최종1\\텀프\\월인천강지곡 권상\\03_type\\*.*");
	while (findfile)
	{
		findfile = finder.FindNextFile(); // m_char (114A~~)

		if (finder.GetFileName() == pSCharInfoWord->m_char)
		{

			str = finder.GetFilePath();
			str += _T("\\*.*");
			findfile = finder.FindFile(str); // m_char 
			while (findfile)
			{
				findfile = finder.FindNextFile();
				str1.Format(_T("%d"), pSCharInfoWord->m_type);

				if (finder.GetFileName() == str1)
				{

					str = finder.GetFilePath();
					str += _T("\\*.*");
					findfile = finder.FindFile(str); // m_char -> m_type
					while (findfile)
					{
						findfile = finder.FindNextFile();
						str = finder.GetFileName();
						// 숫자만 추출
						if (str != _T(".") && str != _T(".."))
						{

							WordInfo* pWordInfo = new WordInfo; // 활자정보가 담긴 WordInfo 구조체의 객체

							CString stack; //임시 저장

							str.Replace(".png", "");
							str.Replace("_", "");
							stack = str;

							str = stack;

							// sx 추출					
							int cnt = str.GetLength();

							if (cnt == 9)
							{
								str = stack.Mid(1, 4); //시트번호가 일의자리수인 경우
							}
							else
								str = stack.Mid(2, 4); //시트번호가 십의자리수인 경우

							arrcnt = 1 + 3 * subcnt;
							pWordInfo->wordsx = _ttoi(str); //sx추출

							// sy 추출
							str = stack.Right(4);
							arrcnt = 2 + 3 * subcnt;
							pWordInfo->wordsy = _ttoi(str); //sy추출

							//sheet 추출
							if (cnt == 9)
							{
								str = stack.Left(1); //시트번호가 일의자리수인 경우
							}
							else
								str = stack.Left(2); //시트번호가 십의자리수인 경우

							arrcnt = 0 + 3 * subcnt;
							pWordInfo->wordsheet = _ttoi(str); //sheet추출
							pWordInfo->worddir = finder.GetFilePath();

							if (_ttoi(str) == pSCharInfoWord->m_sheet)
							{
								dirstr = finder.GetFilePath();
							}
							subcnt++;
							m_word.Add(pWordInfo); // WordInfo 구조체로 이루어진 m_word 배열에 추가
						}
					}
					if (subcnt != 0)
						finder.Close();
				}
			}
		}
	}
	SetStretchBltMode(dc.m_hDC, HALFTONE);
	hResult = Image.Load(dirstr); //불러올 jpg 의 이름
	CPoint point(705, 165);
	dc.LPtoDP(&point);
	Image.StretchBlt(dc.m_hDC, point.x, point.y, 60, 60, 0, 0, 128, 128, SRCCOPY);





	//리스트 컨트롤
	CRect rect;
	m_list.GetClientRect(&rect);
	m_list.SetExtendedStyle(LVS_EX_GRIDLINES | LVS_EX_FULLROWSELECT);
	m_list.InsertColumn(0, _T("장"), LVCFMT_LEFT, rect.Width() * 0.3333333);
	m_list.InsertColumn(1, _T("sx"), LVCFMT_LEFT, rect.Width() * 0.3333333);
	m_list.InsertColumn(1, _T("sy"), LVCFMT_LEFT, rect.Width() * 0.3333333);

	// 새로운 배열 지정
	WordInfo* pWordInfo = new WordInfo;
	m_word.Add(pWordInfo);

	// 버블정렬(m_word 배열을 wordsheet를 기준으로 오름차순)
	for (int i = 0; i < m_word.GetSize() - 1; i++)
	{
		for (int j = 0; j < m_word.GetSize() - i - 2; j++)
		{
			WordInfo* pWordInfo1 = m_word.GetAt(j);
			WordInfo* pWordInfo2 = m_word.GetAt(j + 1);
			if (pWordInfo1->wordsheet > pWordInfo2->wordsheet)
			{
				pWordInfo->wordsheet = pWordInfo1->wordsheet;
				pWordInfo1->wordsheet = pWordInfo2->wordsheet;
				pWordInfo2->wordsheet = pWordInfo->wordsheet;
			}
		}
	}
	// 버블정렬 2
	for (int i = 0; i < m_word.GetSize() - 1; i++)
	{
		for (int j = 0; j < m_word.GetSize() - i - 2; j++)
		{
			WordInfo* pWordInfo1 = m_word.GetAt(j);
			WordInfo* pWordInfo2 = m_word.GetAt(j + 1);
			if (pWordInfo1->wordsheet > pWordInfo2->wordsheet)
			{
				pWordInfo->wordsheet = pWordInfo1->wordsheet;
				pWordInfo1->wordsheet = pWordInfo2->wordsheet;
				pWordInfo2->wordsheet = pWordInfo->wordsheet;
			}

		}
		// 리스트에 관련 글자정보 출력
		pWordInfo = m_word.GetAt(i);
		str.Format(_T("%d"), pWordInfo->wordsheet);
		m_list.InsertItem(i, str);
		str.Format(_T("%d"), pWordInfo->wordsx);
		m_list.SetItem(i, 1, LVIF_TEXT, str, NULL, NULL, NULL, NULL);
		str.Format(_T("%d"), pWordInfo->wordsy);
		m_list.SetItem(i, 2, LVIF_TEXT, str, NULL, NULL, NULL, NULL);
	}
}

void Ctest02Dlg::SelectBox(int chapnum)
{
	// 이미지 불러오기
	HRESULT hResult;
	CImage Image;
	CFileFind finder;

	CClientDC dc(this);
	CPen pen;
	pen.CreatePen(PS_SOLID, 1, RGB(0, 255, 0));
	SCharInfo* pSCharInfo = db.m_Chars.GetAt(0);

	// 사각형 바운더리 관련 선언
	CRect rect;
	CPen* oldPen = dc.SelectObject(&pen);
	CBrush brush;
	brush.CreateStockObject(NULL_BRUSH);
	CBrush* oldBrush = dc.SelectObject(&brush);
	dc.SelectObject(oldBrush);
	DeleteObject(brush);

	oldPen = dc.SelectObject(&pen);
	brush.CreateStockObject(NULL_BRUSH);
	oldBrush = dc.SelectObject(&brush);



	m_rect.SetSize(db.m_Chars.GetSize()); // m_rect 배열의 크기 설정
	// m_rect 배열에 해당 장에 해당하는 csv파일의 데이터를 변환하여 rect 형식으로 저장
	for (int i = 1; i < db.m_Chars.GetSize(); i++)
	{
		pSCharInfo = db.m_Chars.GetAt(i);
		if (pSCharInfo->m_sheet == chapnum)
		{
			// 초록색 박스 생성
			CPen greenpen;
			greenpen.CreatePen(PS_SOLID, 1, RGB(0, 255, 0));
			rect = CRect((20 + pSCharInfo->m_sx / 21.1), (160 + pSCharInfo->m_sy / 21.3), (20 + pSCharInfo->m_sx / 21.1) + pSCharInfo->m_width / 21.1, (160 + pSCharInfo->m_sy / 21.3) + pSCharInfo->m_height / 21.3);
			dc.Rectangle(&rect);

			if (pSCharInfo->m_line == 1 && pSCharInfo->m_order == 1)
			{
				// 1행 1열에는 빨간색 박스 생성
				pSCharInfoWord = db.m_Chars.GetAt(i);
				dc.SelectObject(oldBrush);
				DeleteObject(brush);

				CPen redpen;
				redpen.CreatePen(PS_SOLID, 1, RGB(255, 0, 0));
				oldPen = dc.SelectObject(&redpen);
				brush.CreateStockObject(NULL_BRUSH);
				oldBrush = dc.SelectObject(&brush);

				dc.Rectangle(&rect);
				dc.SelectObject(oldPen);
				m_rect[0] = rect; // 빨간색 rect 정보 저장

				// 글자정보 저장
				wordinf1 = pSCharInfo->m_char;
				wordinf2 = pSCharInfo->m_sheet;
				wordinf3 = pSCharInfo->m_line;
				wordinf4 = pSCharInfo->m_order;

				// 글자정보 출력
				str = pSCharInfo->m_char;
				SetDlgItemText(IDC_WORD1, str);
				str.Format(_T("%d장 %d행 %d번"), pSCharInfo->m_sheet, pSCharInfo->m_line, pSCharInfo->m_order);
				SetDlgItemText(IDC_WORD2, str);

				// 활자 정보 스태틱컨트롤 값 정하기
				int cnt = 0;
				for (int i = 0; i < arrsize; i++)
				{
					SCharInfo* pSCharInfo1 = db.m_Chars.GetAt(i);
					// sheet 번호가 같고, 유니코드 문자도 같은 경우
					if (pSCharInfoWord->m_sheet == pSCharInfo1->m_sheet && pSCharInfoWord->m_char == pSCharInfo1->m_char)
					{
						cnt++;
						str.Format(_T("%d"), cnt);
						str = _T("/") + str;
						str = str + _T("개");
						SetDlgItemText(IDC_STATIC_MOV, str); // 장 내 같은 글자 수 출력(스태틱 텍스트)
					}
				}
				m_spmov.SetRange(1, cnt); // IDC_SPIN_TYPE의 spin 설정
				allmovnum = cnt;
			}
			m_spmov.SetPos(1); // IDC_SPIN_TYPE의 spin 설정
		}
		m_rect[i] = rect; // m_rect 배열에 rect 저장
	}
	dc.SelectObject(oldBrush);
	DeleteObject(brush);
	DeleteObject(pen);

	ReadMovable(); //글자 이미지 읽기
}






class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// 대화 상자 데이터입니다.
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ABOUTBOX };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 지원입니다.

// 구현입니다.
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(IDD_ABOUTBOX)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// Ctest02Dlg 대화 상자



Ctest02Dlg::Ctest02Dlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_TEST02_DIALOG, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	sval = 0;
}

void Ctest02Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT20, m_edsheet);
	DDX_Control(pDX, IDC_SPIN_SHEET, m_spsheet);

	DDX_Control(pDX, IDC_LIST_CHARS, m_list);
	DDX_Control(pDX, IDC_EDIT_MOV, m_edmov);
	DDX_Control(pDX, IDC_SPIN_TYPE, m_spmov);
}

BEGIN_MESSAGE_MAP(Ctest02Dlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON_OPEN, &Ctest02Dlg::OnClickedButtonOpen)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_SHEET, &Ctest02Dlg::OnDeltaposSpinSheet)
	ON_EN_CHANGE(IDC_EDITNUM, &Ctest02Dlg::OnEnChangeEditnum)
	ON_WM_LBUTTONDOWN()
	ON_NOTIFY(NM_CLICK, IDC_LIST_CHARS, &Ctest02Dlg::OnNMClickListChars)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_TYPE, &Ctest02Dlg::OnDeltaposSpinType)
	ON_EN_CHANGE(IDC_INFO1, &Ctest02Dlg::OnEnChangeInfo1)
END_MESSAGE_MAP()


// Ctest02Dlg 메시지 처리기

BOOL Ctest02Dlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	//m_button.LoadStdImage(IDB_PNG1, _T("PNG"));

	// IDM_ABOUTBOX는 시스템 명령 범위에 있어야 합니다.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != nullptr)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}
	
	// 이 대화 상자의 아이콘을 설정합니다.  응용 프로그램의 주 창이 대화 상자가 아닐 경우에는
	//  프레임워크가 이 작업을 자동으로 수행합니다.
	SetIcon(m_hIcon, TRUE);			// 큰 아이콘을 설정합니다.
	SetIcon(m_hIcon, FALSE);		// 작은 아이콘을 설정합니다.
	
	if (this->GetDlgItem(IDC_STATIC_FRAME))
	{
		this->InitVtkWindow(this->GetDlgItem(IDC_STATIC_FRAME)->GetSafeHwnd());
		this->ResizeVtkWindow();
	}
	// TODO: 여기에 추가 초기화 작업을 추가합니다.

	// 장 번호 에디트, 스핀 컨트롤 초기화
	m_edsheet.SetWindowText(_T("1"));
	m_spsheet.SetRange(1, 3);
	m_spsheet.SetPos(1);

	// 활자 번호 에디트, 스핀 컨트롤 초기화
	m_edmov.SetWindowText(_T("1"));
	m_spmov.SetRange(1, 2);
	m_spmov.SetPos(1);
	return TRUE;  // 포커스를 컨트롤에 설정하지 않으면 TRUE를 반환합니다.
}

void Ctest02Dlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// 대화 상자에 최소화 단추를 추가할 경우 아이콘을 그리려면
//  아래 코드가 필요합니다.  문서/뷰 모델을 사용하는 MFC 애플리케이션의 경우에는
//  프레임워크에서 이 작업을 자동으로 수행합니다.

void Ctest02Dlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // 그리기를 위한 디바이스 컨텍스트입니다.

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// 클라이언트 사각형에서 아이콘을 가운데에 맞춥니다.
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// 아이콘을 그립니다.
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();

	}
}


// 사용자가 최소화된 창을 끄는 동안에 커서가 표시되도록 시스템에서
//  이 함수를 호출합니다.
HCURSOR Ctest02Dlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


// 폴더 오픈 시
void Ctest02Dlg::OnClickedButtonOpen()
{
	// 검색버튼 클릭 시

	//csv 파일 불러오기 
	BROWSEINFO brInfo;
	ITEMIDLIST* pIDList;
	CString m_strFolderPath;
	CString strResult;
	char szFilter[500];

	// 이미지 불러오기
	CClientDC dc(this);
	CImage Image;
	HRESULT hResult;

	// 폴더 이름 불러오기
	brInfo.hwndOwner = NULL;
	brInfo.pidlRoot = NULL;
	memset(&brInfo, 0, sizeof(brInfo));
	brInfo.pszDisplayName = szFilter;
	brInfo.lpszTitle = ("폴더를 선택하세요.");
	brInfo.ulFlags = BIF_RETURNONLYFSDIRS;

	pIDList = ::SHBrowseForFolder(&brInfo);

	if (pIDList != NULL)
		::SHGetPathFromIDList(pIDList, szFilter);
	strResult = PathFindFileName(szFilter);
	m_strFolderPath = strResult;

	SetDlgItemText(IDC_EDIT_BOOKNAME, m_strFolderPath);
	GetDlgItemText(IDC_EDIT_BOOKNAME, str);

	CWaitCursor waitcur; // 모래시계 시작(대기)

	if (str == _T("월인천강지곡 권상")) {
		RemoveAll();
		db.ReadCSVFile("typeDB.csv");

		ReadAllBook();

		// 책 전체(1장~3장) 글자수, 글자종류, 활자수 출력
		str.Format(_T("%d 개"), db.m_nChar);
		SetDlgItemText(IDC_ALLBOOK1, str); // 한글 글자 수

		str.Format(_T("%d 종"), lettype);
		SetDlgItemText(IDC_ALLBOOK2, str); // 글자 종류 수

		str.Format(_T("%d 개"), movtype);
		SetDlgItemText(IDC_ALLBOOK3, str); // 한글 활자 수

		// 장 내 글자수, 글자종류, 활자수 출력
		chapnum = 1;
		ReadChapter(chapnum);
		str.Format(_T("%d 개"), chaplet1);
		SetDlgItemText(IDC_CHAPTER1, str);
		str.Format(_T("%d 종"), chaplet2);
		SetDlgItemText(IDC_CHAPTER2, str);
		str.Format(_T("%d 개"), chaplet3);
		SetDlgItemText(IDC_CHAPTER3, str);


		//폴더 선택시 이미지 불러오기
		SetStretchBltMode(dc.m_hDC, HALFTONE);
		hResult = Image.Load(_T("월인천강지곡 권상\\01_scan\\001.jpg")); //불러올 jpg 의 이름
		Image.StretchBlt(dc.m_hDC, 20, 160, 470, 329, 0, 0, 9921, 7015, SRCCOPY);

	}
	else
	{
		AfxMessageBox("폴더 오픈에 실패하였습니다.");
		PostQuitMessage(WM_QUIT);
	} // 폴더 오픈 실패 시

	SelectBox(chapnum); // 초록색 바운더리 생성
	waitcur.Restore(); // 모래시계 해제
	arrsize = db.m_Chars.GetSize();

}

void Ctest02Dlg::OnDeltaposSpinSheet(NMHDR* pNMHDR, LRESULT* pResult)
{
	// 장 번호 스핀 컨트롤 설정
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);

	// sval는 스핀컨트롤의 상태가 3->4 로 가는 상태일때 TRUE(1)이다.
	// 3에서 하나 더 올렸을 경우
	if (sval)
	{
		pNMUpDown->iPos = 1;
		m_spsheet.SetPos(1);
		sval = 0;
	}

	val = pNMUpDown->iPos + pNMUpDown->iDelta; // 값 = 현재 값 + 증/감

	// 3에서 하나 더 올렸을 경우
	if (val == 4 && pNMUpDown->iPos == 3)
	{
		sval = 1;
	}
	if (sval)
	{
		val = 1;
	}

	// 그 값이 1 ~ 3 값이면
	if ((1 <= val) && (val <= 3))
	{
		CString sValue;
		sValue.Format(_T("%d\n"), val);
		m_edsheet.SetWindowText(sValue);
	}
	*pResult = 0;

	chapnum = val;	// 장 번호에 저장
	m_rect.RemoveAll(); // m_rect 배열 제거

	DeleteArr();// m_Chars의 추가배열 삭제
	SelectBox(chapnum);

	// 활자 번호 출력
	str.Format("%d", 1);
	SetDlgItemText(IDC_EDIT_MOV, str);
}


void Ctest02Dlg::OnEnChangeEditnum()
{
	// 장 번호의 숫자에 따라 장 이미지와 장 내 정보들을 출력
	CWaitCursor waitcur; // 모래시계 시작(대기)

	m_edsheet.GetWindowText(str);
	chapnum = _ttoi(str);

	chaplet1 = 0;
	chaplet2 = 0;
	chaplet3 = 0;

	ReadChapter(chapnum);
	//105 67 105 1장
	//120 69 115 2장
	//127 47 115 3장 
	//352 183 335 전체장

	// 장 번호를 읽어 장 내 정보들 출력
	str.Format(_T("%d 개"), chaplet1);
	SetDlgItemText(IDC_CHAPTER1, str);
	str.Format(_T("%d 종"), chaplet2);
	SetDlgItemText(IDC_CHAPTER2, str);
	str.Format(_T("%d 개"), chaplet3);
	SetDlgItemText(IDC_CHAPTER3, str);

	// 이미지 불러오기 위한 선언
	CClientDC dc(this);
	CRect rect;
	CImage Image;
	HRESULT hResult;
	SetStretchBltMode(dc.m_hDC, HALFTONE);

	// 장 번호에 따라 다른 이미지 출력
	switch (chapnum)
	{
		/*LPPOINT point(long 50, long 250);
		dc.LPtoDP(point);*/
		SetStretchBltMode(dc.m_hDC, HALFTONE);

	case 1:
		hResult = Image.Load(_T("월인천강지곡 권상\\01_scan\\001.jpg")); //불러올 jpg 의 이름
		Image.StretchBlt(dc.m_hDC, 20, 160, 470, 329, 0, 0, 9921, 7015, SRCCOPY);
		break;


	case 2:
		hResult = Image.Load(_T("월인천강지곡 권상\\01_scan\\002.jpg")); //불러올 jpg 의 이름
		Image.StretchBlt(dc.m_hDC, 20, 160, 470, 329, 0, 0, 9921, 7015, SRCCOPY);
		break;


	case 3:
		hResult = Image.Load(_T("월인천강지곡 권상\\01_scan\\003.jpg")); //불러올 jpg 의 이름
		Image.StretchBlt(dc.m_hDC, 20, 160, 470, 329, 0, 0, 9921, 7015, SRCCOPY);
		break;
	}
	waitcur.Restore(); // 모래시계 해제
}

//VTK
void Ctest02Dlg::InitVtkWindow(void* hWnd)
{
	if (m_vtkWindow == NULL)
	{
		vtkSmartPointer<vtkRenderWindowInteractor> interactor =
			vtkSmartPointer<vtkRenderWindowInteractor>::New();

		interactor->SetInteractorStyle(
			vtkSmartPointer<vtkInteractorStyleTrackballCamera>::New());

		vtkSmartPointer<vtkRenderer> renderer =
			vtkSmartPointer<vtkRenderer>::New();
		renderer->SetBackground(0.0, 0.0, 0.0);

		m_vtkWindow = vtkSmartPointer<vtkRenderWindow>::New();
		m_vtkWindow->SetParentId(hWnd);
		m_vtkWindow->SetInteractor(interactor);
		m_vtkWindow->AddRenderer(renderer);
		m_vtkWindow->Render();
	}
}

void Ctest02Dlg::ResizeVtkWindow()
{
	CRect rc;
	CWnd* pWnd = GetDlgItem(IDC_STATIC_FRAME);
	if (pWnd)
	{
		pWnd->GetClientRect(rc);
		m_vtkWindow->SetSize(rc.Width(), rc.Height());
	}
}

void Ctest02Dlg::OnLButtonDown(UINT nFlags, CPoint point)
{
	// 클릭 시 초록색 바운더리가 빨간색 바운더리로 변경하며 글자 정보, 활자 정보 갱신
	// 초록색 바운더리 생성하기 위한 선언
	CClientDC dc(this);
	dc.SetMapMode(MM_TEXT);
	CString str;
	CRect rect;
	CRect prerect; // 이전 사각형
	CPen pen;
	CPen redpen;
	CBrush brush;

	vtkSmartPointer<vtkSTLReader> pSTLReader =
		vtkSmartPointer<vtkSTLReader>::New();

	CWaitCursor waitcur; // 모래시계 시작(대기)

	// m_rect에서 rect 값을 받아 사각형 그리기
	for (int i = 1; i < m_rect.GetSize(); i++)
	{
		SCharInfo* pSCharInfo = db.m_Chars.GetAt(i);
		CRect rect;

		rect = m_rect[i];
		prerect = rect;

		if (rect.PtInRect(point))
		{
			DeleteArr(); // 배열 삭제

			pSCharInfoWord = db.m_Chars.GetAt(i);

			// 이전 빨간색 바운더리를 초록색 바운더리로 그리기 설정
			pen.CreatePen(PS_SOLID, 1, RGB(0, 255, 0));
			CPen* oldPen = dc.SelectObject(&pen);
			brush.CreateStockObject(NULL_BRUSH);
			CBrush* oldBrush = dc.SelectObject(&brush);
			oldPen = dc.SelectObject(&pen);

			dc.Rectangle(&m_rect[0]); // 그리기

			// 설정 해제
			dc.SelectObject(oldBrush);
			DeleteObject(brush);
			dc.SelectObject(oldPen);

			str.Format(_T("%d"), 1);
			SetDlgItemText(IDC_EDIT_MOV, str); // 활자 종류 수

			// 선택한 박스를 빨간색 바운더리로 변경
			redpen.CreatePen(PS_SOLID, 1, RGB(255, 0, 0)); // 빨간색 테두리

			// 그리기 설정
			oldPen = dc.SelectObject(&redpen);
			oldBrush = dc.SelectObject(&brush);

			dc.Rectangle(&rect); // 그리기

			// 설정 해제
			dc.SelectObject(oldBrush);
			dc.SelectObject(oldPen);

			m_rect[0] = prerect; // 값 저장

			// 글자 정보 저장
			wordinf1 = pSCharInfoWord->m_char;
			wordinf2 = pSCharInfoWord->m_sheet;
			wordinf3 = pSCharInfoWord->m_line;
			wordinf4 = pSCharInfoWord->m_order;

			// 글자 정보 출력
			str = pSCharInfo->m_char;
			SetDlgItemText(IDC_WORD1, str);
			str.Format(_T("%d장 %d행 %d번"), pSCharInfoWord->m_sheet, pSCharInfoWord->m_line, pSCharInfoWord->m_order);
			SetDlgItemText(IDC_WORD2, str);

			ReadMovable();

			//vtk

			CString VTKFileName = pSCharInfo->m_char;
			CString type;
			type.Format(_T("%d"), pSCharInfo->m_type);
			VTKFileName = "04_3d\\" + VTKFileName + "_" + type + ".stl";
			char* name = LPSTR(LPCTSTR(VTKFileName));//vtk char* 만 읽으므로 형변환
			pSTLReader->SetFileName(name);
			pSTLReader->Update();

			vtkSmartPointer<vtkPolyData> pPolyData =
				pSTLReader->GetOutput();

			vtkSmartPointer<vtkPolyDataMapper> mapper =
				vtkSmartPointer<vtkPolyDataMapper>::New();
			mapper->SetInputData(pPolyData);
			vtkSmartPointer<vtkActor> actor =
				vtkSmartPointer<vtkActor>::New();
			actor->SetMapper(mapper);

			vtkSmartPointer<vtkRenderer> renderer =
				vtkSmartPointer<vtkRenderer>::New();
			renderer->AddActor(actor);
			renderer->SetBackground(.1, .2, .3);
			renderer->ResetCamera();

			m_vtkWindow->AddRenderer(renderer);
			m_vtkWindow->Render();

			// 활자 정보 스태틱컨트롤 값 정하기
			int cnt = 0;
			for (int i = 0; i < arrsize; i++)
			{
				SCharInfo* pSCharInfo1 = db.m_Chars.GetAt(i);
				// sheet 번호와 유니코드 문자열이 같은 경우를 세서 스태틱 텍스트에 출력
				if (pSCharInfoWord->m_sheet == pSCharInfo1->m_sheet && pSCharInfoWord->m_char == pSCharInfo1->m_char)
				{
					cnt++;
					str.Format(_T("%d"), cnt);
					str = _T("/") + str;
					str = str + _T("개");
					SetDlgItemText(IDC_STATIC_MOV, str); // 글자 종류 수
					db.m_Chars.Add(pSCharInfo1); // 배열 추가
				}
			}
			m_spmov.SetRange(1, cnt);
			allmovnum = cnt;
		}
		waitcur.Restore(); // 모래시계 해제
		m_spmov.SetPos(1);


	}

	// 배열 재정렬
	if (arrsize < db.m_Chars.GetSize())
	{
		SCharInfo* pSCharInfo = db.m_Chars.GetAt(arrsize);

		// 같은 활자가 3개 이상(추가배열의 첫 번째 글자 정보가 선택한 글자 정보와 같게 하도록)
		if (allmovnum > 2)
		{
			for (int i = arrsize + 1; i < arrsize + allmovnum; i++)
			{
				SCharInfo* pSCharInfo1 = db.m_Chars.GetAt(i);
				if (pSCharInfo != pSCharInfoWord && pSCharInfo1 == pSCharInfoWord)
				{
					db.m_Chars.SetAt(i, pSCharInfo);
					db.m_Chars.SetAt(arrsize, pSCharInfoWord);
				}
			}
		}

		// 같은 활자가 2개인 경우
		else if (allmovnum == 2)
		{
			SCharInfo* pSCharInfo1 = db.m_Chars.GetAt(arrsize + 1);

			// 추가배열의 첫 번째 글자 정보가 선택한 글자 정보와 다를 경우 
			if (pSCharInfo != pSCharInfoWord)
			{
				db.m_Chars.SetAt(arrsize + 1, pSCharInfo);
				db.m_Chars.SetAt(arrsize, pSCharInfoWord);
			}
		}
	}
	str.Format("%d", 1);
	m_edmov.SetWindowText(str);
	CDialogEx::OnLButtonDown(nFlags, point);
}

void Ctest02Dlg::OnNMClickListChars(NMHDR* pNMHDR, LRESULT* pResult)
{
	// 구성 글자 리스트 표시 및 클릭 시 선택 글자 이미지 표시
	// 리스트컨트롤 설정
	HRESULT hResult;
	CImage Image;
	CClientDC dc(this);
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;
	int idx = pNMListView->iItem;
	WordInfo* pWordInfo = m_word.GetAt(idx);	

	hResult = Image.Load(pWordInfo->worddir); //불러올 jpg 의 이름
	CPoint point;
	point.x = 705;
	point.y = 410;
	dc.LPtoDP(&point);
	Image.StretchBlt(dc.m_hDC, point.x, point.y, 60, 60, 0, 0, 128, 128, SRCCOPY); // 선택 글자 이미지 불러오기
	*pResult = 0;
}


void Ctest02Dlg::OnDeltaposSpinType(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);

	spval = pNMUpDown->iPos + pNMUpDown->iDelta; // 값 = 현재 값 + 증/감

	// 스핀 값이 1과 활자의 전체개수 사이면 출력
	if ((1 <= spval) && (spval <= allmovnum))
	{
		CString sValue;
		sValue.Format(_T("%d\n"), spval);
		m_edmov.SetWindowText(sValue);
	}
	movnum = spval;
	*pResult = 0;
}


void Ctest02Dlg::OnEnChangeInfo1()
{
	BOOL change = FALSE; // IDC_EDIT_MOV의 변화 감지

	// 글자 정보 변경
	m_edmov.GetWindowText(str); // IDC_EDIT_MOV 값 받아오기
	movnum = _ttoi(str);
	SCharInfo* pSCharInfo = new SCharInfo;

	// m_Chars 추가배열이 생겼을 때
	if (arrsize != db.m_Chars.GetSize())
	{
		// 글자 정보 변환
		pSCharInfo = db.m_Chars.GetAt(arrsize - 1 + movnum);
		str = pSCharInfo->m_char;
		SetDlgItemText(IDC_WORD1, str);
		str.Format(_T("%d장 %d행 %d번"), pSCharInfo->m_sheet, pSCharInfo->m_line, pSCharInfo->m_order);
		SetDlgItemText(IDC_WORD2, str);
		change = TRUE;
	}

	// 이미지 출력
	HRESULT hResult;
	CImage Image;
	CString str1;
	CString dirstr;
	CFileFind finder;
	CClientDC dc(this);

	int subcnt = 0; //카운트보조

	// 활자 정보의 IDC_EDIT_MOV에 따라 이미지 출력
	// IDC_EDIT_MOV에 변화가 있을 경우
	if (change)
	{
		BOOL findfile = finder.FindFile("C:\\Users\\82107\\Desktop\\응프텀프\\텀프최종1\\텀프\\월인천강지곡 권상\\03_type\\*.*");
		while (findfile)
		{
			findfile = finder.FindNextFile(); // m_char 

			if (finder.GetFileName() == pSCharInfo->m_char)
			{
				str = finder.GetFilePath();
				str += _T("\\*.*");
				findfile = finder.FindFile(str); // m_char -> m_type
				while (findfile)
				{
					findfile = finder.FindNextFile();
					str1.Format(_T("%d"), pSCharInfo->m_type);

					if (finder.GetFileName() == str1)
					{
						str = finder.GetFilePath();
						str += _T("\\*.*");
						findfile = finder.FindFile(str); // m_char -> m_type -> m_sheet
						while (findfile)
						{
							findfile = finder.FindNextFile();
							str = finder.GetFileName();
							// 숫자만 추출
							if (str != _T(".") && str != _T(".."))
							{
								CString stack; //임시 저장
								str.Replace(".png", "");
								str.Replace("_", "");
								stack = str;
								str = stack;

								// sx 추출					
								int cnt = str.GetLength();

								if (cnt == 9)
								{
									str = stack.Mid(1, 4); //시트번호가 일의자리수인 경우
								}
								else
									str = stack.Mid(2, 4); //시트번호가 십의자리수인 경우

								// sy 추출
								str = stack.Right(4);

								if (cnt == 9)
								{
									str = stack.Left(1); //시트번호가 일의자리수인 경우
								}
								else
									str = stack.Left(2); //시트번호가 십의자리수인 경우

								if (_ttoi(str) == pSCharInfoWord->m_sheet)
								{
									dirstr = finder.GetFilePath();
								}
								subcnt++;
							}
						}
						if (subcnt != 0)
							break;	//탈출
					}
				}
			}
		}
		finder.Close();

		// 이미지 출력
		SetStretchBltMode(dc.m_hDC, HALFTONE);
		hResult = Image.Load(dirstr); //불러올 jpg 의 이름
		CPoint point(705, 165);
		dc.LPtoDP(&point);
		Image.StretchBlt(dc.m_hDC, point.x, point.y, 60, 60, 0, 0, 128, 128, SRCCOPY);

		change = FALSE;
	}
}
